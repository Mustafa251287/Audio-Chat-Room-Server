package com.AudioServer;

public final class BuildConfig {
    public static final String APPLICATION_ID = "${getAppPackageName()}";
    public static final String BUILD_TYPE = "${getBuildTypeName()}";
    public static final boolean DEBUG = Boolean.parseBoolean("true");
    public static final String FLAVOR = "${getFlavorName()}";
    public static final int VERSION_CODE = 0;
    public static final String VERSION_NAME = "${Strings.nullToEmpty(getVersionName())}";
}

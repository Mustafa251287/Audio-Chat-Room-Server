package com.AudioServer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;
import java.util.LinkedList;

public class MainActivity extends Activity {
    Button b1;
    Boolean buttonstatus = false;
    Context context;
    LinkedList<user> list = new LinkedList<>();
    MainActivity mine;
    LinkedList<String> name = new LinkedList<>();
    ServerSocket ss = null;
    TextView t;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().requestFeature(1);
        setContentView(R.layout.activity_main);
        setbackground();
        this.b1 = (Button) findViewById(R.id.btn1);
        this.t = (TextView) findViewById(R.id.tv1);
        try {
            this.t.setTypeface(Typeface.createFromAsset(getAssets(), "b.ttf"), 3);
            this.b1.setTypeface(Typeface.createFromAsset(getAssets(), "db.ttf"), 3);
        } catch (Exception e) {
            tackleerror(e.toString());
        }
        this.context = getApplicationContext();
        this.mine = this;
        SetStatusNavibar(0, 1325420528);
    }

    public void startserver(View view) {
        if (this.buttonstatus.booleanValue()) {
            this.buttonstatus = false;
            this.b1.setTextColor(Color.parseColor("#FF0000"));
            this.b1.setText("Server Stopped");
            closeallsock();
            uitost("Server closed");
            return;
        }
        this.buttonstatus = true;
        this.b1.setTextColor(Color.parseColor("#00FF00"));
        this.b1.setText("Server Started");
        startingserver();
    }

    public void tost(String str) {
        Toast.makeText(this.context, str, 1).show();
    }

    public void uitost(final String str) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(MainActivity.this.context, str, 1).show();
            }
        });
    }

    public void startingserver() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    MainActivity.this.ss = new ServerSocket(22892);
                    MainActivity.this.uitost("Server Started at port:22892");
                    for (int i = 0; i != 4 && MainActivity.this.buttonstatus.booleanValue(); i++) {
                        final Socket accept = MainActivity.this.ss.accept();
                        MainActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                user user = new user(accept, MainActivity.this.mine);
                                MainActivity.this.addUser(user);
                                user.start();
                            }
                        });
                    }
                    MainActivity.this.uitost("Hello world");
                    if (!MainActivity.this.buttonstatus.booleanValue()) {
                        MainActivity.this.uitost("Closing Server on your Request");
                    }
                } catch (Exception e) {
                    MainActivity.this.tackleerror("Function Startingserver " + e.toString());
                }
            }
        }).start();
    }

    public void tackleerror(final String str) {
        runOnUiThread(new Runnable() {
            public void run() {
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(new File(MainActivity.this.getExternalCacheDir(), "Error.txt"), true);
                    fileOutputStream.write(("\n" + str).getBytes());
                    fileOutputStream.close();
                    MainActivity.this.uitost(str);
                } catch (Exception e) {
                    MainActivity.this.uitost(e.toString());
                }
            }
        });
    }

    public void broadcastbytes(byte[] bArr, int i, user user) {
        try {
            Iterator it = this.list.iterator();
            while (it.hasNext()) {
                user user2 = (user) it.next();
                if (user2 != user) {
                    user2.sendbytes(bArr, i);
                }
            }
        } catch (Exception e) {
            e.toString();
            tackleerror("Broadcastbytes of Mainactivity.java file :" + e.toString());
        }
    }

    public void Brodcast(String str, user user) {
        try {
            Iterator it = this.list.iterator();
            while (it.hasNext()) {
                user user2 = (user) it.next();
                if (user2 != user) {
                    user2.sendmessage(str);
                }
            }
        } catch (Exception e) {
            tackleerror(e.toString());
        }
    }

    public void Brodcast(String str) {
        try {
            Iterator it = this.list.iterator();
            while (it.hasNext()) {
                ((user) it.next()).sendmessage(str);
            }
        } catch (Exception e) {
            tackleerror(e.toString());
        }
    }

    public boolean hasUser() {
        return !this.name.isEmpty();
    }

    public String getAllUserName() {
        if (!hasUser()) {
            return "No User Connected yet";
        }
        String str = "";
        Iterator it = this.name.iterator();
        while (true) {
            String str2 = str;
            if (!it.hasNext()) {
                return str2;
            }
            str = String.valueOf(str2) + ((String) it.next()) + " ";
        }
    }

    public void addUser(user user) {
        this.list.add(user);
    }

    public void addName(String str) {
        this.name.add(str);
    }

    public void removeUser(user user) {
        this.list.remove(user);
    }

    public void removeName(String str) {
        this.name.remove(str);
    }

    public void SetStatusNavibar(int i, int i2) {
        if (Build.VERSION.SDK_INT > 19) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.getDecorView().setSystemUiVisibility(1792);
            window.setStatusBarColor(i2);
            window.setNavigationBarColor(i);
        }
    }

    public void setbackground() {
        ((RelativeLayout) findViewById(R.id.l1)).setBackgroundResource(R.drawable.back);
    }

    public void closeallsock() {
        try {
            Iterator it = this.list.iterator();
            while (it.hasNext()) {
                user user = (user) it.next();
                user.dout.close();
                user.din.close();
                user.s.close();
                user.s = null;
            }
        } catch (Exception e) {
            uitost(e.toString());
        }
    }
}

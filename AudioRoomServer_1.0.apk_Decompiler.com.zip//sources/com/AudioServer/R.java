package com.AudioServer;

public final class R {

    public static final class attr {
    }

    public static final class color {
        public static final int _light_green = 2130968661;
        public static final int alice_blue = 2130968620;
        public static final int antique_white = 2130968610;
        public static final int aqua = 2130968700;
        public static final int aquamarine = 2130968673;
        public static final int azure = 2130968618;
        public static final int beige = 2130968615;
        public static final int bisque = 2130968589;
        public static final int black = 2130968715;
        public static final int blanched_almond = 2130968587;
        public static final int blue = 2130968711;
        public static final int blue_violet = 2130968666;
        public static final int brown = 2130968654;
        public static final int burlyWood = 2130968628;
        public static final int cadet_blue = 2130968684;
        public static final int chartreuse = 2130968674;
        public static final int chocolate = 2130968638;
        public static final int cold = 2130968593;
        public static final int coral = 2130968599;
        public static final int cornflower_blue = 2130968683;
        public static final int cornsilk = 2130968583;
        public static final int crimson = 2130968631;
        public static final int cyan = 2130968701;
        public static final int dark_blue = 2130968713;
        public static final int dark_cyan = 2130968707;
        public static final int dark_goldenrod = 2130968646;
        public static final int dark_gray = 2130968653;
        public static final int dark_green = 2130968710;
        public static final int dark_khaki = 2130968643;
        public static final int dark_magenta = 2130968664;
        public static final int dark_olive_green = 2130968685;
        public static final int dark_orange = 2130968598;
        public static final int dark_orchid = 2130968657;
        public static final int dark_red = 2130968665;
        public static final int dark_salmon = 2130968625;
        public static final int dark_sea_green = 2130968662;
        public static final int dark_slate_blue = 2130968688;
        public static final int dark_slate_gray = 2130968694;
        public static final int dark_turquoise = 2130968705;
        public static final int dark_violet = 2130968659;
        public static final int deep_pink = 2130968603;
        public static final int deep_sky_blue = 2130968706;
        public static final int dim_gray = 2130968681;
        public static final int dodger_blue = 2130968698;
        public static final int fire_brick = 2130968647;
        public static final int floral_white = 2130968581;
        public static final int forest_green = 2130968696;
        public static final int fuchsia = 2130968604;
        public static final int gainsboro = 2130968630;
        public static final int ghost_white = 2130968612;
        public static final int goldenrod = 2130968633;
        public static final int gray = 2130968669;
        public static final int green = 2130968709;
        public static final int greenYellow = 2130968651;
        public static final int honeydew = 2130968619;
        public static final int hot_pink = 2130968600;
        public static final int indian_red = 2130968640;
        public static final int indigo = 2130968686;
        public static final int ivory = 2130968577;
        public static final int khaki = 2130968621;
        public static final int lavender = 2130968626;
        public static final int lavender_blush = 2130968585;
        public static final int lawn_green = 2130968675;
        public static final int lemon_chiffon = 2130968582;
        public static final int light_blue = 2130968652;
        public static final int light_coral = 2130968622;
        public static final int light_cyan = 2130968627;
        public static final int light_goldenrod_yellow = 2130968608;
        public static final int light_grey = 2130968636;
        public static final int light_pink = 2130968595;
        public static final int light_salmon = 2130968597;
        public static final int light_sea_green = 2130968697;
        public static final int light_sky_blue = 2130968667;
        public static final int light_slate_gray = 2130968677;
        public static final int light_steel_blue = 2130968649;
        public static final int light_yellow = 2130968578;
        public static final int lime = 2130968703;
        public static final int lime_green = 2130968693;
        public static final int linen = 2130968609;
        public static final int magenta = 2130968605;
        public static final int maroon = 2130968672;
        public static final int mediumPurple = 2130968660;
        public static final int medium_aquamarine = 2130968682;
        public static final int medium_blue = 2130968712;
        public static final int medium_orchid = 2130968645;
        public static final int medium_sea_green = 2130968692;
        public static final int medium_slate_blue = 2130968676;
        public static final int medium_spring_green = 2130968704;
        public static final int medium_turquoise = 2130968687;
        public static final int medium_violet_red = 2130968641;
        public static final int midnight_blue = 2130968699;
        public static final int mint_cream = 2130968613;
        public static final int misty_rose = 2130968588;
        public static final int moccasin = 2130968590;
        public static final int navajo_white = 2130968591;
        public static final int navy = 2130968714;
        public static final int old_lace = 2130968607;
        public static final int olive = 2130968670;
        public static final int olive_drab = 2130968679;
        public static final int orange = 2130968596;
        public static final int orange_red = 2130968602;
        public static final int orchid = 2130968634;
        public static final int pale_goldenrod = 2130968623;
        public static final int pale_green = 2130968658;
        public static final int pale_turquoise = 2130968650;
        public static final int pale_violet_red = 2130968632;
        public static final int papaya_whip = 2130968586;
        public static final int peach_puff = 2130968592;
        public static final int peru = 2130968639;
        public static final int pink = 2130968594;
        public static final int plum = 2130968629;
        public static final int powder_blue = 2130968648;
        public static final int purple = 2130968671;
        public static final int red = 2130968606;
        public static final int rosy_brown = 2130968644;
        public static final int royal_blue = 2130968690;
        public static final int saddle_brown = 2130968663;
        public static final int salmon = 2130968611;
        public static final int sandy_brown = 2130968617;
        public static final int sea_green = 2130968695;
        public static final int seashell = 2130968584;
        public static final int sienna = 2130968655;
        public static final int silver = 2130968642;
        public static final int sky_blue = 2130968668;
        public static final int slate_blue = 2130968680;
        public static final int slate_gray = 2130968678;
        public static final int snow = 2130968580;
        public static final int spring_green = 2130968702;
        public static final int steel_blue = 2130968689;
        public static final int tan = 2130968637;
        public static final int teal = 2130968708;
        public static final int thistle = 2130968635;
        public static final int tomato = 2130968601;
        public static final int turquoise = 2130968691;
        public static final int violet = 2130968624;
        public static final int wheat = 2130968616;
        public static final int white = 2130968576;
        public static final int white_smoke = 2130968614;
        public static final int yellow = 2130968579;
        public static final int yellow_green = 2130968656;
    }

    public static final class drawable {
        public static final int b = 2130837504;
        public static final int back = 2130837505;
        public static final int button_bg = 2130837506;
        public static final int d = 2130837507;
        public static final int db = 2130837508;
        public static final int ic_launcher = 2130837509;
        public static final int ser = 2130837510;
    }

    public static final class id {
        public static final int btn1 = 2131165186;
        public static final int l1 = 2131165184;
        public static final int tv1 = 2131165185;
    }

    public static final class layout {
        public static final int activity_main = 2130903040;
    }

    public static final class string {
        public static final int app_name = 2131034112;
        public static final int title_activity_main = 2131034113;
    }

    public static final class style {
        public static final int AppTheme = 2131099648;
    }
}

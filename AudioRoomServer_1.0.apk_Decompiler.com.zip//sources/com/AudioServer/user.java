package com.AudioServer;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class user extends Thread {
    DataInputStream din;
    DataOutputStream dout;
    MainActivity main;
    Socket s;
    user thisuser = this;

    public void run() {
        try {
            this.dout = new DataOutputStream(this.s.getOutputStream());
            this.din = new DataInputStream(this.s.getInputStream());
            String readUTF = this.din.readUTF();
            this.main.addName(readUTF);
            this.main.uitost(String.valueOf(readUTF) + " joined the room");
            printuser();
            byte[] bArr = new byte[10000];
            while (true) {
                int read = this.din.read(bArr);
                if (read == -1) {
                    this.main.uitost(String.valueOf(readUTF) + " left");
                    this.main.removeName(readUTF);
                    this.main.removeUser(this.thisuser);
                    Thread.sleep(500);
                    printuser();
                    closeall();
                    return;
                } else if (read >= 100) {
                    this.main.broadcastbytes(bArr, read, this.thisuser);
                }
            }
        } catch (Exception e) {
            this.main.tackleerror("user object error " + e.toString());
        }
    }

    public user(Socket socket, MainActivity mainActivity) {
        this.s = socket;
        this.main = mainActivity;
    }

    public void sendbytes(byte[] bArr, int i) {
        try {
            this.dout.write(bArr, 0, i);
        } catch (Exception e) {
            this.main.tackleerror("Send bytes function of user.java file " + e.toString());
        }
    }

    public void sendmessage(String str) throws IOException {
        this.dout.writeUTF(str);
        this.main.uitost(str);
    }

    public void printuser() {
        this.main.Brodcast(encodemystring("Connected Users:" + this.main.getAllUserName()));
    }

    public void closeall() {
        try {
            this.dout.close();
            this.din.close();
            this.s.close();
        } catch (Exception e) {
            this.main.tackleerror("Error in closing Sockets in user.java \n" + e);
        }
    }

    public String encodemystring(String str) {
        Charset charset = StandardCharsets.UTF_8;
        return new String(charset.encode(str).array(), charset);
    }
}
